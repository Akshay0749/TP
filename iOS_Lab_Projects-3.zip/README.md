# iOS Lab Projects (Login, Exp 6, Exp 9, Exp 10)

Each folder is a complete Xcode project. Double-click the `.xcodeproj` inside it:

| Folder | Open this | Experiment |
|---|---|---|
| Login | Login/Login.xcodeproj | Exp 8: Login app |
| ApplePie | ApplePie/ApplePie.xcodeproj | Exp 6: Apple Pie game |
| AboutMe | AboutMe/AboutMe.xcodeproj | Exp 9: Tab bar "AboutMe" |
| OrderOfEvents | OrderOfEvents/OrderOfEvents.xcodeproj | Exp 10: lifecycle events |

## Run

1. Open the `.xcodeproj` (needs Xcode 16 or later).
2. Choose an iPhone simulator in the top bar.
3. Press the Run button (Cmd+R). Build is Cmd+B.

If Xcode shows a signing warning, click the project > Signing & Capabilities > pick your Personal Team. Simulator runs do not need it.

## Files in each project

AppDelegate.swift, SceneDelegate.swift, Assets.xcassets and the view controllers live in the app folder. There is no Info.plist file; its settings are in the project build settings.

## Personalise Exp 9

Edit the lines marked with a pencil emoji in ProfileViewController, HobbiesViewController and ContactViewController.

## Exp 10

Open the debug console (Cmd+Shift+Y) and switch tabs to see the numbered lifecycle log. The same log is shown on screen.
