//
//  ViewController.swift
//  Login
//
//  Experiment 8: Login application.
//  Follows the lab manual: usernameField, passwordField, resultLabel and the
//  loginTapped action. The screen is built in code instead of the storyboard,
//  so there are no outlet connections to break.
//

import UIKit

class ViewController: UIViewController {

    // Views (named exactly as in the lab manual)
    let usernameField = UITextField()
    let passwordField = UITextField()
    let resultLabel = UILabel()

    // Model: predefined credentials (from the manual)
    let validUsername = "admin"
    let validPassword = "1234"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        buildInterface()
    }

    // MARK: - Interface

    func buildInterface() {
        let titleLabel = UILabel()
        titleLabel.text = "Login"
        titleLabel.font = .boldSystemFont(ofSize: 34)
        titleLabel.textAlignment = .center

        usernameField.placeholder = "Username"
        usernameField.borderStyle = .roundedRect
        usernameField.autocapitalizationType = .none
        usernameField.autocorrectionType = .no
        usernameField.returnKeyType = .next
        usernameField.delegate = self

        passwordField.placeholder = "Password"
        passwordField.borderStyle = .roundedRect
        passwordField.isSecureTextEntry = true
        passwordField.returnKeyType = .done
        passwordField.delegate = self

        var config = UIButton.Configuration.filled()
        config.title = "Login"
        config.cornerStyle = .large
        let loginButton = UIButton(configuration: config)
        loginButton.addTarget(self, action: #selector(loginTapped(_:)), for: .touchUpInside)

        resultLabel.text = "Enter your credentials"
        resultLabel.textAlignment = .center
        resultLabel.numberOfLines = 0
        resultLabel.textColor = .secondaryLabel
        resultLabel.font = .systemFont(ofSize: 18, weight: .medium)

        let hintLabel = UILabel()
        hintLabel.text = "Hint: admin / 1234"
        hintLabel.textAlignment = .center
        hintLabel.font = .systemFont(ofSize: 13)
        hintLabel.textColor = .tertiaryLabel

        let stack = UIStackView(arrangedSubviews: [titleLabel, usernameField, passwordField,
                                                   loginButton, resultLabel, hintLabel])
        stack.axis = .vertical
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: guide.centerYAnchor, constant: -60),
            stack.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 32),
            stack.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -32),
            usernameField.heightAnchor.constraint(equalToConstant: 44),
            passwordField.heightAnchor.constraint(equalToConstant: 44),
            loginButton.heightAnchor.constraint(equalToConstant: 48)
        ])

        // Tap anywhere to dismiss the keyboard
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    // MARK: - Action (code from the lab manual)

    @IBAction func loginTapped(_ sender: UIButton) {
        view.endEditing(true)
        let username = usernameField.text
        let password = passwordField.text

        if username == validUsername && password == validPassword {
            resultLabel.text = "Login Successful ✅"
            resultLabel.textColor = .systemGreen
        } else {
            resultLabel.text = "Invalid Credentials ❌"
            resultLabel.textColor = .systemRed
        }
    }
}

// MARK: - Return key handling

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == usernameField {
            passwordField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return true
    }
}
