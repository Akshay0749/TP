//
//  ViewController.swift
//  Login
//
//  Experiment 8: Login application (code follows the lab manual).
//

import UIKit

class ViewController: UIViewController {

    let usernameField = UITextField()
    let passwordField = UITextField()
    let resultLabel = UILabel()

    // Predefined credentials (from the manual)
    let validUsername = "admin"
    let validPassword = "1234"

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let titleLabel = UILabel()
        titleLabel.text = "Login"
        titleLabel.font = .boldSystemFont(ofSize: 30)
        titleLabel.textAlignment = .center

        usernameField.placeholder = "Username"
        usernameField.borderStyle = .roundedRect
        usernameField.autocapitalizationType = .none
        usernameField.autocorrectionType = .no

        passwordField.placeholder = "Password"
        passwordField.borderStyle = .roundedRect
        passwordField.isSecureTextEntry = true

        let loginButton = UIButton(type: .system)
        loginButton.setTitle("Login", for: .normal)
        loginButton.titleLabel?.font = .boldSystemFont(ofSize: 18)
        loginButton.addTarget(self, action: #selector(loginTapped(_:)), for: .touchUpInside)

        resultLabel.textAlignment = .center
        resultLabel.font = .systemFont(ofSize: 17)

        let stack = UIStackView(arrangedSubviews: [titleLabel, usernameField, passwordField,
                                                   loginButton, resultLabel])
        stack.axis = .vertical
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -80),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40)
        ])
    }

    // Code from the lab manual
    @IBAction func loginTapped(_ sender: UIButton) {
        let username = usernameField.text
        let password = passwordField.text

        if username == validUsername && password == validPassword {
            resultLabel.text = "Login Successful"
            resultLabel.textColor = .systemGreen
        } else {
            resultLabel.text = "Invalid Credentials"
            resultLabel.textColor = .systemRed
        }
    }
}
